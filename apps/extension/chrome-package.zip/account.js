/* empty css                    */import{O as Ze,a as ce,s as Qe,b as Xe,c as I,r as et}from"./chunks/openapps-session-CfJo0664.js";import{e as j}from"./chunks/webext-DWUUb8S3.js";let ee=null;function ze(n){return ee=new Ze(n),w(),ee}function tt(n,e){if(n)return n;if(ee)return ee;if(e)return ze({baseUrl:e});throw new Error("no OpenApps client: call configure({ baseUrl }) or set base-url on the element")}const de=new Set;function rt(n){return de.add(n),()=>de.delete(n)}function w(){for(const n of de)n()}/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Q=globalThis,me=Q.ShadowRoot&&(Q.ShadyCSS===void 0||Q.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,be=Symbol(),_e=new WeakMap;let He=class{constructor(e,t,r){if(this._$cssResult$=!0,r!==be)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(me&&e===void 0){const r=t!==void 0&&t.length===1;r&&(e=_e.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),r&&_e.set(t,e))}return e}toString(){return this.cssText}};const nt=n=>new He(typeof n=="string"?n:n+"",void 0,be),U=(n,...e)=>{const t=n.length===1?n[0]:e.reduce((r,s,i)=>r+(o=>{if(o._$cssResult$===!0)return o.cssText;if(typeof o=="number")return o;throw Error("Value passed to 'css' function must be a 'css' function result: "+o+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(s)+n[i+1],n[0]);return new He(t,n,be)},st=(n,e)=>{if(me)n.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const t of e){const r=document.createElement("style"),s=Q.litNonce;s!==void 0&&r.setAttribute("nonce",s),r.textContent=t.cssText,n.appendChild(r)}},Ce=me?n=>n:n=>n instanceof CSSStyleSheet?(e=>{let t="";for(const r of e.cssRules)t+=r.cssText;return nt(t)})(n):n;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:it,defineProperty:ot,getOwnPropertyDescriptor:at,getOwnPropertyNames:lt,getOwnPropertySymbols:ct,getPrototypeOf:dt}=Object,ne=globalThis,Ae=ne.trustedTypes,ht=Ae?Ae.emptyScript:"",ut=ne.reactiveElementPolyfillSupport,F=(n,e)=>n,te={toAttribute(n,e){switch(e){case Boolean:n=n?ht:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,e){let t=n;switch(e){case Boolean:t=n!==null;break;case Number:t=n===null?null:Number(n);break;case Object:case Array:try{t=JSON.parse(n)}catch{t=null}}return t}},ve=(n,e)=>!it(n,e),Se={attribute:!0,type:String,converter:te,reflect:!1,useDefault:!1,hasChanged:ve};Symbol.metadata??=Symbol("metadata"),ne.litPropertyMetadata??=new WeakMap;let T=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=Se){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){const r=Symbol(),s=this.getPropertyDescriptor(e,r,t);s!==void 0&&ot(this.prototype,e,s)}}static getPropertyDescriptor(e,t,r){const{get:s,set:i}=at(this.prototype,e)??{get(){return this[t]},set(o){this[t]=o}};return{get:s,set(o){const l=s?.call(this);i?.call(this,o),this.requestUpdate(e,l,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??Se}static _$Ei(){if(this.hasOwnProperty(F("elementProperties")))return;const e=dt(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(F("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(F("properties"))){const t=this.properties,r=[...lt(t),...ct(t)];for(const s of r)this.createProperty(s,t[s])}const e=this[Symbol.metadata];if(e!==null){const t=litPropertyMetadata.get(e);if(t!==void 0)for(const[r,s]of t)this.elementProperties.set(r,s)}this._$Eh=new Map;for(const[t,r]of this.elementProperties){const s=this._$Eu(t,r);s!==void 0&&this._$Eh.set(s,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const r=new Set(e.flat(1/0).reverse());for(const s of r)t.unshift(Ce(s))}else e!==void 0&&t.push(Ce(e));return t}static _$Eu(e,t){const r=t.attribute;return r===!1?void 0:typeof r=="string"?r:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const r of t.keys())this.hasOwnProperty(r)&&(e.set(r,this[r]),delete this[r]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return st(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,r){this._$AK(e,r)}_$ET(e,t){const r=this.constructor.elementProperties.get(e),s=this.constructor._$Eu(e,r);if(s!==void 0&&r.reflect===!0){const i=(r.converter?.toAttribute!==void 0?r.converter:te).toAttribute(t,r.type);this._$Em=e,i==null?this.removeAttribute(s):this.setAttribute(s,i),this._$Em=null}}_$AK(e,t){const r=this.constructor,s=r._$Eh.get(e);if(s!==void 0&&this._$Em!==s){const i=r.getPropertyOptions(s),o=typeof i.converter=="function"?{fromAttribute:i.converter}:i.converter?.fromAttribute!==void 0?i.converter:te;this._$Em=s;const l=o.fromAttribute(t,i.type);this[s]=l??this._$Ej?.get(s)??l,this._$Em=null}}requestUpdate(e,t,r,s=!1,i){if(e!==void 0){const o=this.constructor;if(s===!1&&(i=this[e]),r??=o.getPropertyOptions(e),!((r.hasChanged??ve)(i,t)||r.useDefault&&r.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(o._$Eu(e,r))))return;this.C(e,t,r)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(e,t,{useDefault:r,reflect:s,wrapped:i},o){r&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,o??t??this[e]),i!==!0||o!==void 0)||(this._$AL.has(e)||(this.hasUpdated||r||(t=void 0),this._$AL.set(e,t)),s===!0&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[s,i]of this._$Ep)this[s]=i;this._$Ep=void 0}const r=this.constructor.elementProperties;if(r.size>0)for(const[s,i]of r){const{wrapped:o}=i,l=this[s];o!==!0||this._$AL.has(s)||l===void 0||this.C(s,void 0,i,l)}}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(r=>r.hostUpdate?.()),this.update(t)):this._$EM()}catch(r){throw e=!1,this._$EM(),r}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(e){}firstUpdated(e){}};T.elementStyles=[],T.shadowRootOptions={mode:"open"},T[F("elementProperties")]=new Map,T[F("finalized")]=new Map,ut?.({ReactiveElement:T}),(ne.reactiveElementVersions??=[]).push("2.1.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ye=globalThis,Ee=n=>n,re=ye.trustedTypes,Oe=re?re.createPolicy("lit-html",{createHTML:n=>n}):void 0,De="$lit$",_=`lit$${Math.random().toFixed(9).slice(2)}$`,Be="?"+_,pt=`<${Be}>`,L=document,V=()=>L.createComment(""),J=n=>n===null||typeof n!="object"&&typeof n!="function",we=Array.isArray,ft=n=>we(n)||typeof n?.[Symbol.iterator]=="function",ae=`[ 	
\f\r]`,G=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Pe=/-->/g,Le=/>/g,O=RegExp(`>|${ae}(?:([^\\s"'>=/]+)(${ae}*=${ae}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Ne=/'/g,Ue=/"/g,Ge=/^(?:script|style|textarea|title)$/i,We=n=>(e,...t)=>({_$litType$:n,strings:e,values:t}),a=We(1),$e=We(2),z=Symbol.for("lit-noChange"),c=Symbol.for("lit-nothing"),Re=new WeakMap,P=L.createTreeWalker(L,129);function Fe(n,e){if(!we(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return Oe!==void 0?Oe.createHTML(e):e}const gt=(n,e)=>{const t=n.length-1,r=[];let s,i=e===2?"<svg>":e===3?"<math>":"",o=G;for(let l=0;l<t;l++){const d=n[l];let h,f,u=-1,m=0;for(;m<d.length&&(o.lastIndex=m,f=o.exec(d),f!==null);)m=o.lastIndex,o===G?f[1]==="!--"?o=Pe:f[1]!==void 0?o=Le:f[2]!==void 0?(Ge.test(f[2])&&(s=RegExp("</"+f[2],"g")),o=O):f[3]!==void 0&&(o=O):o===O?f[0]===">"?(o=s??G,u=-1):f[1]===void 0?u=-2:(u=o.lastIndex-f[2].length,h=f[1],o=f[3]===void 0?O:f[3]==='"'?Ue:Ne):o===Ue||o===Ne?o=O:o===Pe||o===Le?o=G:(o=O,s=void 0);const y=o===O&&n[l+1].startsWith("/>")?" ":"";i+=o===G?d+pt:u>=0?(r.push(h),d.slice(0,u)+De+d.slice(u)+_+y):d+_+(u===-2?l:y)}return[Fe(n,i+(n[t]||"<?>")+(e===2?"</svg>":e===3?"</math>":"")),r]};class K{constructor({strings:e,_$litType$:t},r){let s;this.parts=[];let i=0,o=0;const l=e.length-1,d=this.parts,[h,f]=gt(e,t);if(this.el=K.createElement(h,r),P.currentNode=this.el.content,t===2||t===3){const u=this.el.content.firstChild;u.replaceWith(...u.childNodes)}for(;(s=P.nextNode())!==null&&d.length<l;){if(s.nodeType===1){if(s.hasAttributes())for(const u of s.getAttributeNames())if(u.endsWith(De)){const m=f[o++],y=s.getAttribute(u).split(_),M=/([.?@])?(.*)/.exec(m);d.push({type:1,index:i,name:M[2],strings:y,ctor:M[1]==="."?bt:M[1]==="?"?vt:M[1]==="@"?yt:se}),s.removeAttribute(u)}else u.startsWith(_)&&(d.push({type:6,index:i}),s.removeAttribute(u));if(Ge.test(s.tagName)){const u=s.textContent.split(_),m=u.length-1;if(m>0){s.textContent=re?re.emptyScript:"";for(let y=0;y<m;y++)s.append(u[y],V()),P.nextNode(),d.push({type:2,index:++i});s.append(u[m],V())}}}else if(s.nodeType===8)if(s.data===Be)d.push({type:2,index:i});else{let u=-1;for(;(u=s.data.indexOf(_,u+1))!==-1;)d.push({type:7,index:i}),u+=_.length-1}i++}}static createElement(e,t){const r=L.createElement("template");return r.innerHTML=e,r}}function H(n,e,t=n,r){if(e===z)return e;let s=r!==void 0?t._$Co?.[r]:t._$Cl;const i=J(e)?void 0:e._$litDirective$;return s?.constructor!==i&&(s?._$AO?.(!1),i===void 0?s=void 0:(s=new i(n),s._$AT(n,t,r)),r!==void 0?(t._$Co??=[])[r]=s:t._$Cl=s),s!==void 0&&(e=H(n,s._$AS(n,e.values),s,r)),e}class mt{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:r}=this._$AD,s=(e?.creationScope??L).importNode(t,!0);P.currentNode=s;let i=P.nextNode(),o=0,l=0,d=r[0];for(;d!==void 0;){if(o===d.index){let h;d.type===2?h=new Z(i,i.nextSibling,this,e):d.type===1?h=new d.ctor(i,d.name,d.strings,this,e):d.type===6&&(h=new wt(i,this,e)),this._$AV.push(h),d=r[++l]}o!==d?.index&&(i=P.nextNode(),o++)}return P.currentNode=L,s}p(e){let t=0;for(const r of this._$AV)r!==void 0&&(r.strings!==void 0?(r._$AI(e,r,t),t+=r.strings.length-2):r._$AI(e[t])),t++}}class Z{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,r,s){this.type=2,this._$AH=c,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=r,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=H(this,e,t),J(e)?e===c||e==null||e===""?(this._$AH!==c&&this._$AR(),this._$AH=c):e!==this._$AH&&e!==z&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):ft(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==c&&J(this._$AH)?this._$AA.nextSibling.data=e:this.T(L.createTextNode(e)),this._$AH=e}$(e){const{values:t,_$litType$:r}=e,s=typeof r=="number"?this._$AC(e):(r.el===void 0&&(r.el=K.createElement(Fe(r.h,r.h[0]),this.options)),r);if(this._$AH?._$AD===s)this._$AH.p(t);else{const i=new mt(s,this),o=i.u(this.options);i.p(t),this.T(o),this._$AH=i}}_$AC(e){let t=Re.get(e.strings);return t===void 0&&Re.set(e.strings,t=new K(e)),t}k(e){we(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let r,s=0;for(const i of e)s===t.length?t.push(r=new Z(this.O(V()),this.O(V()),this,this.options)):r=t[s],r._$AI(i),s++;s<t.length&&(this._$AR(r&&r._$AB.nextSibling,s),t.length=s)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){const r=Ee(e).nextSibling;Ee(e).remove(),e=r}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}}class se{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,r,s,i){this.type=1,this._$AH=c,this._$AN=void 0,this.element=e,this.name=t,this._$AM=s,this.options=i,r.length>2||r[0]!==""||r[1]!==""?(this._$AH=Array(r.length-1).fill(new String),this.strings=r):this._$AH=c}_$AI(e,t=this,r,s){const i=this.strings;let o=!1;if(i===void 0)e=H(this,e,t,0),o=!J(e)||e!==this._$AH&&e!==z,o&&(this._$AH=e);else{const l=e;let d,h;for(e=i[0],d=0;d<i.length-1;d++)h=H(this,l[r+d],t,d),h===z&&(h=this._$AH[d]),o||=!J(h)||h!==this._$AH[d],h===c?e=c:e!==c&&(e+=(h??"")+i[d+1]),this._$AH[d]=h}o&&!s&&this.j(e)}j(e){e===c?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class bt extends se{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===c?void 0:e}}class vt extends se{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==c)}}class yt extends se{constructor(e,t,r,s,i){super(e,t,r,s,i),this.type=5}_$AI(e,t=this){if((e=H(this,e,t,0)??c)===z)return;const r=this._$AH,s=e===c&&r!==c||e.capture!==r.capture||e.once!==r.once||e.passive!==r.passive,i=e!==c&&(r===c||s);s&&this.element.removeEventListener(this.name,this,r),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}}class wt{constructor(e,t,r){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=r}get _$AU(){return this._$AM._$AU}_$AI(e){H(this,e)}}const $t=ye.litHtmlPolyfillSupport;$t?.(K,Z),(ye.litHtmlVersions??=[]).push("3.3.3");const kt=(n,e,t)=>{const r=t?.renderBefore??e;let s=r._$litPart$;if(s===void 0){const i=t?.renderBefore??null;r._$litPart$=s=new Z(e.insertBefore(V(),i),i,void 0,t??{})}return s._$AI(n),s};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ke=globalThis;class q extends T{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=kt(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return z}}q._$litElement$=!0,q.finalized=!0,ke.litElementHydrateSupport?.({LitElement:q});const xt=ke.litElementPolyfillSupport;xt?.({LitElement:q});(ke.litElementVersions??=[]).push("4.2.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const D=n=>(e,t)=>{t!==void 0?t.addInitializer(()=>{customElements.define(n,e)}):customElements.define(n,e)};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const _t={attribute:!0,type:String,converter:te,reflect:!1,hasChanged:ve},Ct=(n=_t,e,t)=>{const{kind:r,metadata:s}=t;let i=globalThis.litPropertyMetadata.get(s);if(i===void 0&&globalThis.litPropertyMetadata.set(s,i=new Map),r==="setter"&&((n=Object.create(n)).wrapped=!0),i.set(t.name,n),r==="accessor"){const{name:o}=t;return{set(l){const d=e.get.call(this);e.set.call(this,l),this.requestUpdate(o,d,n,!0,l)},init(l){return l!==void 0&&this.C(o,void 0,n,l),l}}}if(r==="setter"){const{name:o}=t;return function(l){const d=this[o];e.call(this,l),this.requestUpdate(o,d,n,!0,l)}}throw Error("Unsupported decorator location: "+r)};function v(n){return(e,t)=>typeof t=="object"?Ct(n,e,t):((r,s,i)=>{const o=s.hasOwnProperty(i);return s.constructor.createProperty(i,r),o?Object.getOwnPropertyDescriptor(s,i):void 0})(n,e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function p(n){return v({...n,state:!0,attribute:!1})}var ie=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};class b extends q{constructor(){super(...arguments),this.error=null,this.busy=!1}#e;connectedCallback(){super.connectedCallback(),this.#e=rt(()=>this.onSessionChange())}disconnectedCallback(){this.#e?.(),super.disconnectedCallback()}onSessionChange(){this.requestUpdate()}get sdk(){return tt(this.client,this.baseUrl)}get sdkOrNull(){try{return this.sdk}catch{return null}}async run(e){this.error=null,this.busy=!0;try{return await e()}catch(t){if(t instanceof Error&&t.name==="AbortError")return;this.error=At(t);return}finally{this.busy=!1}}emit(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}static{this.baseStyles=U`
    :host {
      /* Fallback palette: the design system's light values, inlined. */
      --fb-card: #ffffff;
      --fb-subtle: #f8f8f7;
      --fb-hairline: #deded9;
      --fb-strong: #020202;
      --fb-body: #3d3d3d;
      --fb-muted: #656565;
      --fb-faint: #7c7c7c;
      --fb-brand: #00c896;
      --fb-selected: #e6f9f3;
      --fb-danger: #b3261e;

      display: block;
      font: var(--type-body, 400 15px/1.45 "Geist", system-ui, sans-serif);
      letter-spacing: var(--tracking-body, -0.005em);
      color: var(--text-body, var(--fb-body));
    }

    /* Only the *fallbacks* follow the OS. Once tokens are linked, dark mode
       is the host's decision via the oa-auto / oa-dark classes, and a
       component running its own media query would sit stubbornly light
       inside a host that had deliberately forced dark. */
    @media (prefers-color-scheme: dark) {
      :host {
        --fb-card: #1a1a1a;
        --fb-subtle: #1a1a1a;
        --fb-hairline: rgba(255, 255, 255, 0.1);
        --fb-strong: #ffffff;
        --fb-body: rgba(255, 255, 255, 0.7);
        --fb-muted: rgba(255, 255, 255, 0.6);
        --fb-faint: rgba(255, 255, 255, 0.4);
        --fb-selected: #10312a;
        --fb-danger: #ff4d4d;
      }
    }

    /* ---- The SDK frame ----
       One card, capped at --sdk-max. It never assumes a page, so it drops
       into a modal, a settings pane, a phone screen or a route unchanged. */
    .panel {
      width: 100%;
      max-width: var(--sdk-max, 420px);
      background: var(--surface-card, var(--fb-card));
      border: var(--border-width, 1px) solid
        var(--border-hairline, var(--fb-hairline));
      border-radius: var(--radius-xl, 16px);
      box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.08));
      overflow: hidden;
      box-sizing: border-box;
    }

    .panel.wide {
      max-width: var(--sdk-wide, 560px);
    }

    .head {
      display: grid;
      gap: 8px;
      padding: 24px 24px 0;
    }

    .title {
      margin: 0;
      font: var(--weight-medium, 500) var(--text-xl, 24px) / 1.2
        var(--font-display, "Geist", system-ui, sans-serif);
      letter-spacing: var(--tracking-heading, -0.02em);
      color: var(--text-strong, var(--fb-strong));
    }

    .desc {
      margin: 0;
      font: var(--type-body, 400 15px/1.45 "Geist", system-ui, sans-serif);
      color: var(--text-muted, var(--fb-muted));
    }

    .body {
      display: grid;
      gap: 14px;
      padding: 24px;
    }

    /* A labelled rule, for "or" between a provider row and the rest. */
    .divider {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .divider::before,
    .divider::after {
      content: "";
      flex: 1;
      height: 1px;
      background: var(--border-hairline, var(--fb-hairline));
    }

    .caption {
      margin: 0;
      font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
      color: var(--text-faint, var(--fb-faint));
    }

    .eyebrow {
      font: var(--type-eyebrow, 500 12px/1.2 "Geist", system-ui, sans-serif);
      letter-spacing: var(--tracking-caps, 0.08em);
      text-transform: uppercase;
      color: var(--text-faint, var(--fb-faint));
    }

    /* The O monogram on a squircle. No logo was ever supplied, so the mark
       is typographic by design: legible at 16px, works in one colour, and
       re-skins from the --logo-* tokens without redrawing anything. */
    .mark {
      display: grid;
      place-items: center;
      width: 30px;
      height: 30px;
      border-radius: var(--logo-tile-radius, 0.22em);
      background: var(--logo-tile-bg, var(--fb-strong));
      color: var(--logo-tile-fg, var(--fb-brand));
      font: var(--weight-medium, 500) 18px / 1
        var(--font-display, "Geist", system-ui, sans-serif);
      letter-spacing: var(--logo-tracking, -0.04em);
      user-select: none;
    }

    /* A value the user is meant to copy: an address, an invoice, a link.
       Shared because three elements render one and a fourth will. */
    .payload {
      display: block;
      overflow-wrap: anywhere;
      padding: 0.6em;
      border: var(--border-width, 1px) solid
        var(--border-hairline, var(--fb-hairline));
      border-radius: var(--radius-lg, 12px);
      background: var(--bg-subtle, var(--fb-subtle));
      font: var(--type-mono, 400 13px/1.5 ui-monospace, monospace);
      color: var(--text-body, var(--fb-body));
    }

    /* ---- Badge ----
       A read-only status pill. Never given a click handler: a badge that
       does something is a control wearing a status's clothes. */
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      height: 22px;
      padding: 0 8px;
      border-radius: var(--radius-full, 999px);
      font: var(--weight-medium, 500) var(--text-xs, 12px) / 1
        var(--font-sans, "Geist", system-ui, sans-serif);
      white-space: nowrap;
      background: var(--bg-sunken, #f2f2f2);
      color: var(--text-muted, var(--fb-muted));
    }

    .badge.success {
      background: var(--success-bg, #e6f9f3);
      color: var(--success-fg, #0b8a68);
    }

    .badge.danger {
      background: var(--danger-bg, #fdecea);
      color: var(--danger-fg, var(--fb-danger));
    }

    .badge.brand {
      background: var(--brand-soft, #e6f9f3);
      color: var(--text-brand, var(--fb-brand));
    }

    /* Inherits the pill's colour, so a tone change carries the dot with it. */
    .badge .dot {
      width: 5px;
      height: 5px;
      border-radius: var(--radius-full, 999px);
      background: currentColor;
    }

    /* ---- Field ----
       Label, control, hint. Focus is a near-black border plus the offset
       ring — never a coloured glow, and never a removed outline. */
    .field {
      display: grid;
      gap: 6px;
    }

    .field label {
      font: var(--type-ui, 500 13px/1.3 "Geist", system-ui, sans-serif);
      color: var(--text-strong, var(--fb-strong));
    }

    .field input {
      width: 100%;
      box-sizing: border-box;
      min-height: var(--control-h-md, 36px);
      padding: 0 12px;
      border: var(--border-width, 1px) solid
        var(--border-hairline, var(--fb-hairline));
      border-radius: var(--radius-md, 8px);
      background: var(--surface-card, var(--fb-card));
      color: var(--text-strong, var(--fb-strong));
      font: var(--type-body, 400 15px/1.45 "Geist", system-ui, sans-serif);
      letter-spacing: inherit;
    }

    .field input::placeholder {
      color: var(--text-faint, var(--fb-faint));
    }

    .field input:focus-visible {
      border-color: var(--text-strong, var(--fb-strong));
      box-shadow: var(--focus-ring, 0 0 0 2px #f2f2f2, 0 0 0 4px #020202);
    }

    .field .hint {
      font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
      color: var(--text-faint, var(--fb-faint));
    }

    /* Anything numeric — balances, prices, per-unit rates, ledger amounts. */
    .mono {
      font-family: var(--font-mono, "Geist Mono", ui-monospace, monospace);
      font-variant-numeric: tabular-nums;
    }

    /* ---- Controls ----
       Height comes from the platform tokens, which re-point themselves under
       a pointer:coarse media query, so touch targets clear 44px with no
       mobile-specific variant here. */
    button {
      font: var(--type-ui, 500 13px/1.3 "Geist", system-ui, sans-serif);
      letter-spacing: inherit;
      cursor: pointer;
      min-height: var(--control-h-md, 36px);
      padding: 0 14px;
      border-radius: var(--radius-md, 8px);
      border: var(--border-width, 1px) solid
        var(--border-hairline, var(--fb-hairline));
      background: var(--surface-card, var(--fb-card));
      color: var(--text-strong, var(--fb-strong));
      transition: var(--transition-control, all 120ms cubic-bezier(0.2, 0, 0, 1));
    }

    button:hover:not([disabled]) {
      background: var(--surface-hover, rgba(0, 0, 0, 0.04));
    }

    /* The whole press feedback is half a pixel. Nothing scales. */
    button:active:not([disabled]) {
      transform: translateY(0.5px);
    }

    button.primary {
      background: var(--brand, var(--fb-brand));
      border-color: var(--brand, var(--fb-brand));
      color: var(--brand-contrast, #020202);
    }

    button.primary:hover:not([disabled]) {
      background: var(--brand-soft, #1ad3a5);
    }

    button.ghost {
      background: transparent;
      border-color: transparent;
    }

    button.block {
      width: 100%;
      justify-content: center;
    }

    button[disabled] {
      opacity: 0.45;
      cursor: not-allowed;
    }

    /* A ring, never a glow, and never removed. */
    :focus-visible {
      outline: none;
      box-shadow: var(--focus-ring, 0 0 0 2px #f2f2f2, 0 0 0 4px #020202);
    }

    a {
      color: var(--text-link, var(--fb-strong));
      text-decoration: none;
      text-underline-offset: 3px;
    }

    a:hover {
      text-decoration: underline;
    }

    .error {
      color: var(--danger-fg, var(--fb-danger));
      font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
      margin-top: 0.5em;
    }

    .muted {
      color: var(--text-muted, var(--fb-muted));
    }
  `}}ie([v({type:String,attribute:"base-url"})],b.prototype,"baseUrl",void 0);ie([v({attribute:!1})],b.prototype,"client",void 0);ie([p()],b.prototype,"error",void 0);ie([p()],b.prototype,"busy",void 0);function At(n){if(n instanceof ce)switch(n.code){case"unauthorized":return"Please sign in again.";case"insufficient_balance":return n.balance===void 0?"Not enough credits.":`Not enough credits — you have ${n.balance}.`;case"rate_limited":return"Too many attempts. Please wait a moment and try again.";case"network":return"Could not reach the server. Check your connection.";case"timeout":return"This is taking longer than expected. It may still complete.";default:return n.message}return n instanceof Error?n.message:String(n)}const St=$e`<svg viewBox="0 0 18 18" width="16" height="16" aria-hidden="true" focusable="false"><path fill="#4285F4" d="M17.64 9.205c0-.639-.057-1.252-.164-1.841H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.258h2.909c1.702-1.567 2.683-3.874 2.683-6.614z"/><path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.181l-2.909-2.258c-.806.54-1.837.859-3.047.859-2.344 0-4.328-1.583-5.036-3.71H.957v2.332A8.997 8.997 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/><path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.346l2.582-2.582C13.463.892 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"/></svg>`,Et=$e`<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><g fill="#627EEA"><path d="M12 1.5 5.75 12.02 12 15.73V1.5z" opacity=".55"/><path d="M12 1.5v14.23l6.25-3.71L12 1.5z" opacity=".85"/><path d="M12 17.06 5.75 13.35 12 22.5v-5.44z" opacity=".55"/><path d="M12 22.5v-5.44l6.25-3.71L12 22.5z" opacity=".85"/></g></svg>`,Ot=$e`<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="#9C59FF" d="M3 23.9C2.7 23.6 2.8 22.7 3.3 22.1C3.4 21.9 3.4 21.9 3.2 21.9C3 22 2.9 21.9 2.9 21.6C3 21.3 3.4 21 3.9 20.9C4.4 20.8 4.4 20.8 5.2 19.5C5.7 18.9 6.3 18.1 6.5 17.7C6.9 17.2 7 17 7.1 16.8C7.2 16.3 7.4 16 7.9 15.8C8.5 15.6 10.4 13.8 10.2 13.6C10.2 13.6 10 13.6 9.7 13.5C8.7 13.3 7.5 12.8 6.9 12.4C6.6 12.2 6.6 12.2 6.4 12.2C5.6 12.3 4.9 12.5 4.4 12.8C3.8 13.1 3.8 13.2 3.7 13.1C3.6 13 3.6 12.4 3.8 12C3.8 11.9 3.8 11.9 3.7 11.9C3.6 11.9 3.4 12 3.1 12.3C2.7 12.8 2.6 12.8 2.5 12.6C2.3 12.4 2.4 12.1 2.5 11.7C2.6 11.2 2.6 11.2 2.5 11.2C2.4 11.3 2.2 11.4 2 11.4C1.6 11.6 1.5 11.6 1.5 11.4C1.5 10.7 2.3 9.7 3 9.3C3.7 8.9 4.9 8.8 5.2 9C5.3 9.1 5.6 9.2 5.6 9.2C5.6 9.2 5.6 9.1 5.5 9C5.4 8.8 5.4 8.6 5.5 8.6C5.5 8.6 5.9 8.6 6.3 8.6C7.6 8.6 8.1 8.4 9.4 7.8C10.9 7.1 11.1 7 11.7 6.8C12.5 6.5 12.9 6.4 13.9 6.4C15.4 6.3 16 6.5 17.4 7.3C18 7.7 18.1 7.7 18.4 7.6C18.7 7.6 18.8 7.6 19.1 7.6C19.7 7.7 20 7.7 20.4 7.5C21.1 7.1 21.4 6.5 21.3 5.7C21.3 5 21.1 4.7 20.2 4.1C19.1 3.2 18.7 2.5 18.7 1.5C18.7 0.9 18.8 0.6 19.1 0.3C19.5 -0.1 19.9 -0.1 20.6 0.4C21 0.6 21.2 0.7 21.8 0.9C22.6 1.2 22.7 1.2 22.2 1.3C21.8 1.3 21.8 1.3 22.1 1.4C22.7 1.6 22.6 1.7 21.7 1.7C21.1 1.7 20.9 1.7 20.6 1.8C20.1 1.9 20 2 20.1 2.2C20.1 2.5 20.2 2.6 20.9 3.1C22.1 4.1 22.5 4.8 22.5 6C22.4 7.5 21.5 8.7 19.8 9.8C19.2 10.1 19.2 10.1 19.2 10.7C19.2 11.9 19 12.5 18.3 13.1C17.5 13.7 16.6 13.9 15.1 14L14.3 14L14.2 14.2C14.1 14.2 14.1 14.3 14.1 14.4C14.1 14.4 13.8 14.6 13.5 14.8C13.2 15 12.6 15.8 12.9 15.7C12.9 15.7 13.4 15.5 14 15.3C17 14.4 16.7 14.5 17.2 14.5C17.8 14.5 17.8 14.5 18.4 15.4C19 16.3 19.1 16.5 19 16.6C19 16.8 18.5 16.6 18 16.1C17.7 15.8 17.6 15.8 17.7 16.1C17.7 16.4 17.6 16.5 17.4 16.4C17.3 16.3 17.2 16.2 17.1 15.8L17.1 15.5L16.9 15.5C16.6 15.5 16.6 15.5 14.5 16.2C13.3 16.6 12.9 16.7 12.7 16.9C12 17.2 11.5 17 11.5 16.3C11.5 16.1 11.9 14.9 12.1 14.8C12.1 14.8 12.3 14.4 12.2 14.4C12.2 14.4 11.9 14.5 11.6 14.6L11 14.8L10 15.6C9 16.4 9 16.4 8.9 16.6C8.8 17 8.5 17.3 8.1 17.4C7.9 17.5 7.8 17.7 6.9 18.8C5.9 20.1 5.3 20.9 4.9 21.6C4.8 21.8 4.5 22.1 4.3 22.4C3.7 22.9 3.6 23.1 3.3 23.6C3.1 24 3.1 24 3 23.9Z"/></svg>`,Pt=(function(){const e=typeof document<"u"&&document.createElement("link").relList;return e&&e.supports&&e.supports("modulepreload")?"modulepreload":"preload"})(),Lt=function(n){return"/"+n},Me={},he=function(e,t,r){let s=Promise.resolve();if(t&&t.length>0){let o=function(h){return Promise.all(h.map(f=>Promise.resolve(f).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const l=document.querySelector("meta[property=csp-nonce]"),d=l?.nonce||l?.getAttribute("nonce");s=o(t.map(h=>{if(h=Lt(h),h in Me)return;Me[h]=!0;const f=h.endsWith(".css"),u=f?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${u}`))return;const m=document.createElement("link");if(m.rel=f?"stylesheet":Pt,f||(m.as="script"),m.crossOrigin="",m.href=h,d&&m.setAttribute("nonce",d),document.head.appendChild(m),f)return new Promise((y,M)=>{m.addEventListener("load",y),m.addEventListener("error",()=>M(new Error(`Unable to preload CSS for ${h}`)))})}))}function i(o){const l=new Event("vite:preloadError",{cancelable:!0});if(l.payload=o,window.dispatchEvent(l),!l.defaultPrevented)throw o}return s.then(o=>{for(const l of o||[])l.status==="rejected"&&i(l.reason);return e().catch(i)})};class g extends Error{constructor(e){super(e),this.name="WalletError"}}function qe(){return typeof window>"u"?[]:[{where:"window.nostr",provider:window.nostr},{where:"window.okxwallet.nostr",provider:window.okxwallet?.nostr}]}function Nt(n){const e=n;return!!e&&typeof e.getPublicKey=="function"&&typeof e.signEvent=="function"}function Ut(){for(const{provider:n}of qe())if(Nt(n))return n;return null}async function Ve(n=2e3){const e=Date.now()+n;for(;;){const t=Ut();if(t)return t;const r=e-Date.now();if(r<=0)return null;await new Promise(s=>setTimeout(s,Math.min(100,r)))}}function Je(){return qe().map(n=>n.where)}function Ke(){if(typeof window>"u")return null;for(const n of[window.ethereum,window.okxwallet])if(n&&typeof n.request=="function")return n;return null}async function Rt(n,e){let t;try{t=JSON.parse(n)}catch{throw new g("server sent an unreadable Nostr challenge")}const{nip19:r,finalizeEvent:s}=await he(async()=>{const{nip19:o,finalizeEvent:l}=await import("./chunks/index-DUBistDv.js");return{nip19:o,finalizeEvent:l}},[]);let i;try{const o=r.decode(e.trim());if(o.type!=="nsec")throw new g(`that is an ${o.type} key — sign-in needs the secret key, which starts with nsec1`);i=o.data}catch(o){throw o instanceof g?o:new g("that does not look like a valid nsec1… key")}try{const o=s({kind:t.kind,content:t.content,tags:t.tags,created_at:t.created_at??Math.floor(Date.now()/1e3)},i);return{type:"nostr_event",event:JSON.stringify(o)}}finally{i.fill(0)}}async function ue(){const n=Ke();if(!n)throw new g("no Ethereum wallet found in this browser");let e;try{e=await n.request({method:"eth_requestAccounts"})}catch(r){throw new g(xe(r,"wallet connection was rejected"))}const t=Array.isArray(e)?e[0]:void 0;if(typeof t!="string"||!t)throw new g("wallet returned no accounts");return t}async function pe(n,e){const t=Ke();if(!t)throw new g("no Ethereum wallet found in this browser");try{const r=await t.request({method:"personal_sign",params:[n,e]});if(typeof r!="string")throw new g("wallet returned no signature");return{type:"signature",signature:r}}catch(r){throw r instanceof g?r:new g(xe(r,"signature was rejected"))}}async function fe(n){const e=await Ve();if(!e)throw new g(`no Nostr signer answered (looked at ${Je().join(", ")})`);let t;try{t=JSON.parse(n)}catch{throw new g("server sent an unreadable Nostr challenge")}t.created_at??=Math.floor(Date.now()/1e3);try{const r=await e.signEvent(t);return{type:"nostr_event",event:JSON.stringify(r)}}catch(r){throw new g(xe(r,"signing was rejected"))}}const Mt=6e4;async function Tt(n,e,t={}){let r;try{r=JSON.parse(n)}catch{throw new g("server sent an unreadable Nostr challenge")}const[{BunkerSigner:s,parseBunkerInput:i},{generateSecretKey:o}]=await Promise.all([he(()=>import("./chunks/nip46-AzsyChLv.js"),[]),he(()=>import("./chunks/pure-B-kxY_Vu.js"),[])]),l=await i(e.trim()).catch(()=>null);if(!l)throw new g("that is not a bunker:// address or a NIP-05 name — copy the connection string from your signer app");const d=s.fromBunker(o(),l,{onauth:h=>t.onAuthUrl?.(h)});try{const h=await It((async()=>(await d.connect(),d.signEvent({kind:r.kind,content:r.content,tags:r.tags,created_at:r.created_at??Math.floor(Date.now()/1e3)})))(),t.timeoutMs??Mt,"the signer did not respond — check it is running and try again");return{type:"nostr_event",event:JSON.stringify(h)}}catch(h){throw h instanceof g?h:new g(h instanceof Error?h.message:"the remote signer refused")}finally{await d.close().catch(()=>{})}}function It(n,e,t){return new Promise((r,s)=>{const i=setTimeout(()=>s(new g(t)),e);n.then(o=>{clearTimeout(i),r(o)},o=>{clearTimeout(i),s(o)})})}function xe(n,e){if(n&&typeof n=="object"){const t=n;if(t.code===4001)return e;if(t.message)return t.message}return e}var A=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};let $=class extends b{constructor(){super(...arguments),this.me=null,this.enabled=null,this.signerTimeout=2e3,this.variant="inline",this.nostrFallback="none",this.nostrHint=null,this.authUrl=null}connectedCallback(){super.connectedCallback(),this.load()}onSessionChange(){this.load()}async load(){const e=await this.run(()=>this.sdk.auth.completeRedirect());if(e&&(this.emit("openapps-login",e),w()),this.enabled||(this.enabled=await this.run(()=>this.sdk.auth.methods())??null),!this.sdk.isLoggedIn){this.me=null;return}this.me=await this.run(()=>this.sdk.auth.me())??null}async loginWithWallet(){await this.run(async()=>{const e=await ue(),t=await this.sdk.auth.challenge("eip155",e),r=await pe(t.message,e),s=await this.sdk.auth.verify(t.challenge_id,r,{referralCode:W()});this.emit("openapps-login",s),w()})}async loginWithNostr(){if(!await Ve(this.signerTimeout)){this.nostrFallback="bunker",this.nostrHint=`No signer extension answered. Checked ${Je().join(" and ")}. On a phone, or without an extension, connect a remote signer below.`;return}await this.run(async()=>{const e=await this.sdk.auth.challenge("nostr"),t=await fe(e.message),r=await this.sdk.auth.verify(e.challenge_id,t,{referralCode:W()});this.emit("openapps-login",r),w()})}async loginWithBunker(e){e.preventDefault();const r=this.renderRoot.querySelector("#bunker")?.value.trim()??"";r&&(this.authUrl=null,await this.run(async()=>{const s=await this.sdk.auth.challenge("nostr"),i=await Tt(s.message,r,{onAuthUrl:l=>{this.authUrl=l}}),o=await this.sdk.auth.verify(s.challenge_id,i,{referralCode:W()});this.nostrFallback="none",this.authUrl=null,this.emit("openapps-login",o),w()}))}async loginWithNsec(e){e.preventDefault();const t=this.renderRoot.querySelector("#nsec"),r=t?.value.trim()??"";r&&await this.run(async()=>{try{const s=await this.sdk.auth.challenge("nostr"),i=await Rt(s.message,r),o=await this.sdk.auth.verify(s.challenge_id,i,{referralCode:W()});this.nostrFallback="none",this.emit("openapps-login",o),w()}finally{t&&(t.value="")}})}loginWithGoogle(){const e=`${location.origin}${location.pathname}${location.search}`;window.location.href=this.sdk.auth.googleStartUrl(e,W())}async logout(){await this.run(()=>this.sdk.auth.logout()),this.me=null,this.emit("openapps-logout",null),w()}render(){if(this.me)return this.renderSignedIn(this.me);const e=this.enabled?.google??!1,t=this.enabled?.eip155??!1,r=this.enabled?.nostr??!1;if(this.enabled&&!e&&!t&&!r)return this.frame(a`
        <p class="muted">This server has no login methods configured.</p>
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      `);const s=this.variant==="panel"?"block":"";return this.frame(a`
      <div class="stack">
        ${e?a`<button
              class="provider ${s}"
              ?disabled=${this.busy}
              @click=${this.loginWithGoogle}
            >
              ${St}<span>Continue with Google</span>
            </button>`:c}
        ${t?a`<button
              class="provider ${s}"
              ?disabled=${this.busy}
              @click=${this.loginWithWallet}
            >
              ${Et}<span>Continue with a wallet</span>
            </button>`:c}
        ${r?a`
              <button
                class="provider ${s}"
                ?disabled=${this.busy}
                @click=${this.loginWithNostr}
              >
                ${Ot}<span>Continue with Nostr</span>
              </button>
              ${this.renderNostrFallback()}
            `:c}
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      </div>
    `)}frame(e){return this.variant!=="panel"?e:a`
      <div class="panel">
        <div class="head">
          <span class="mark" aria-hidden="true">O</span>
          <h1 class="title">Sign in to OpenApps</h1>
          <p class="desc">
            One account for every app in the suite. Optional — the apps work
            without it.
          </p>
        </div>
        <div class="body">${e}</div>
      </div>
    `}renderNostrFallback(){return this.nostrFallback==="bunker"?this.renderBunkerForm():this.nostrFallback==="nsec"?this.renderNsecForm():a`
      <button
        class="link"
        ?disabled=${this.busy}
        @click=${()=>{this.nostrFallback="bunker",this.nostrHint=null}}
      >
        No extension? Use a remote signer
      </button>
    `}renderBunkerForm(){return a`
      <form class="nsec" @submit=${this.loginWithBunker}>
        ${this.nostrHint?a`<p class="muted small">${this.nostrHint}</p>`:c}
        <p class="muted small">
          Paste the connection string from your signer — Amber, nsec.app, or your
          own bunker. It looks like <code>bunker://…</code>, or you can use a
          NIP-05 name. <strong>Your key never leaves the signer</strong>; only the
          request to sign travels, and you approve it there.
        </p>
        <div class="field">
          <label for="bunker">Remote signer</label>
          <input
            id="bunker"
            type="text"
            placeholder="bunker://… or you@example.com"
            autocomplete="off"
            autocapitalize="off"
            autocorrect="off"
            spellcheck="false"
            ?disabled=${this.busy}
          />
          <span class="hint">
            A bunker URI, or the NIP-05 address your signer is reachable at.
          </span>
        </div>
        ${this.authUrl?a`<p class="muted small">
              Your signer needs approval:
              <a href=${this.authUrl} target="_blank" rel="noreferrer noopener"
                >open it</a
              >, then come back.
            </p>`:c}
        <div class="row">
          <button class="primary" type="submit" ?disabled=${this.busy}>
            ${this.busy?"Waiting for your signer…":"Connect signer"}
          </button>
          <button
            type="button"
            ?disabled=${this.busy}
            @click=${()=>this.nostrFallback="none"}
          >
            Cancel
          </button>
        </div>
        <button
          class="link"
          type="button"
          ?disabled=${this.busy}
          @click=${()=>{this.nostrFallback="nsec",this.nostrHint=null}}
        >
          I only have a private key
        </button>
      </form>
    `}renderNsecForm(){return a`
      <form class="nsec" @submit=${this.loginWithNsec}>
        ${this.nostrHint?a`<p class="muted small">${this.nostrHint}</p>`:c}
        <p class="warn">
          <strong>Only do this on a key you can afford to lose.</strong>
          An <code>nsec</code> is your whole Nostr identity — it cannot be changed
          without abandoning the account, and any script on this page can read it
          while you paste it. A signer extension exists so a website never sees
          your key.
        </p>
        <div class="field">
          <label for="nsec">Secret key</label>
          <input
            id="nsec"
            type="password"
            placeholder="nsec1…"
            autocomplete="off"
            autocapitalize="off"
            autocorrect="off"
            spellcheck="false"
            ?disabled=${this.busy}
          />
        </div>
        <p class="muted small">
          The key is used in this browser to sign one message. It is not sent to
          the server and not saved anywhere.
        </p>
        <div class="row">
          <button class="primary" type="submit" ?disabled=${this.busy}>
            Sign in
          </button>
          <button type="button" ?disabled=${this.busy} @click=${()=>this.nostrFallback="none"}>
            Cancel
          </button>
        </div>
      </form>
    `}renderSignedIn(e){const t=e.display_name??e.linked_accounts[0]?.caip10??e.id;return a`
      <div class="row">
        <span class="identity" title=${t}>${jt(t)}</span>
        <button ?disabled=${this.busy} @click=${this.logout}>Sign out</button>
      </div>
      ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
    `}static{this.styles=[b.baseStyles,U`
      /* Mark on the left, label centred in the space that remains — so the
         three labels line up with each other rather than each sitting a
         different distance from its own icon. */
      button.provider {
        display: flex;
        align-items: center;
        gap: 10px;
        text-align: left;
      }
      button.provider svg {
        flex: none;
      }
      button.provider.block span {
        flex: 1;
        text-align: center;
        /* Balance the mark so the label is centred on the button, not on
           the space beside the mark. */
        margin-right: 26px;
      }
      .stack {
        display: flex;
        flex-direction: column;
        gap: 0.5em;
      }
      .row {
        display: flex;
        align-items: center;
        gap: 0.75em;
      }
      .identity {
        font-variant-numeric: tabular-nums;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      button.link {
        border: none;
        background: none;
        color: var(--text-muted, var(--fb-muted));
        text-decoration: underline;
        padding: 0.1em 0;
        font-size: 0.85em;
        text-align: left;
      }
      .nsec {
        display: flex;
        flex-direction: column;
        gap: 0.5em;
        border: 1px solid var(--border-hairline, var(--fb-hairline));
        border-radius: var(--radius-lg, 12px);
        padding: 0.8em;
      }
      /* Everything else comes from .field. Only the family is overridden:
         a key is a literal, and mono carries literals. */
      .nsec input {
        font-family: var(--font-mono, "Geist Mono", ui-monospace, monospace);
      }
      /* Semantic tokens, so a host forcing dark gets the dark warning —
         the hardcoded pair here used its own media query and so ignored
         the host entirely. */
      .warn {
        font-size: 0.8rem;
        margin: 0;
        padding: 0.5em 0.6em;
        border-radius: var(--radius-lg, 12px);
        background: var(--warning-bg, #fef3c7);
        color: var(--warning-fg, #92400e);
      }
      .small {
        font-size: 0.78rem;
      }
      .row {
        display: flex;
        gap: 0.5em;
      }
    `]}};A([p()],$.prototype,"me",void 0);A([p()],$.prototype,"enabled",void 0);A([v({type:Number,attribute:"signer-timeout"})],$.prototype,"signerTimeout",void 0);A([v({type:String})],$.prototype,"variant",void 0);A([p()],$.prototype,"nostrFallback",void 0);A([p()],$.prototype,"nostrHint",void 0);A([p()],$.prototype,"authUrl",void 0);$=A([D("openapps-login")],$);function jt(n,e=10,t=6){return n.length<=e+t+1?n:`${n.slice(0,e)}…${n.slice(-t)}`}function W(){return typeof location>"u"?void 0:new URLSearchParams(location.search).get("ref")??void 0}var B=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};const le={google:"Google",eip155:"Wallet",nostr:"Nostr"};let N=class extends b{constructor(){super(...arguments),this.me=null,this.enabled=null,this.pending=null,this.notice=null,this.blocked=null}connectedCallback(){super.connectedCallback(),this.load()}onSessionChange(){this.load()}async load(){if(await Promise.resolve(),this.handleLinkRedirect(),this.enabled||(this.enabled=await this.run(()=>this.sdk.auth.methods())??null),!this.sdk.isLoggedIn){this.me=null;return}this.me=await this.run(()=>this.sdk.auth.me())??null}linked(e){return(this.me?.linked_accounts??[]).some(t=>t.namespace===e)}get connectable(){return["eip155","nostr"].filter(e=>this.enabled?.[e]&&!this.linked(e))}get canConnectGoogle(){return(this.enabled?.google??!1)&&!this.linked("google")}async connectGoogle(e=!1){await this.run(async()=>{const t=`${location.origin}${location.pathname}${location.search}`,r=await this.sdk.auth.googleLinkStart(t,{merge:e});window.location.href=r})}handleLinkRedirect(){let e;try{e=this.sdk.auth.completeLinkRedirect()}catch{return}if(e)switch(e.status){case"linked":this.notice=e.merged?`Accounts combined — ${e.credits.toLocaleString()} credits moved across.`:"Google connected.",this.emit("openapps-identity-linked",e),w();break;case"conflict":this.pending={namespace:"google",other:{id:"",balance:e.balance}};break;case"blocked":this.blocked=e.message;break;case"error":this.error=e.message;break}}async connect(e){this.blocked=null,await this.run(async()=>{const t=e==="eip155"?await ue():void 0,r=await this.sdk.auth.linkChallenge(e,t),s=e==="eip155"?await pe(r.message,t):await fe(r.message);try{const i=await this.sdk.auth.linkVerify(r.challenge_id,s);this.afterLink(i)}catch(i){if(i instanceof ce&&(i.detail?.code==="merge_blocked_by_duplicate_namespace"||i.detail?.code==="namespace_already_linked")){this.blocked=i.message;return}if(i instanceof ce&&i.detail?.code==="identity_belongs_to_another_account"){this.pending={namespace:e,other:i.detail.other_account};return}throw i}})}async confirmMerge(){const e=this.pending;if(e){if(e.namespace==="google"){this.pending=null,await this.connectGoogle(!0);return}await this.run(async()=>{const t=e.namespace==="eip155"?await ue():void 0,r=await this.sdk.auth.linkChallenge(e.namespace,t),s=e.namespace==="eip155"?await pe(r.message,t):await fe(r.message),i=await this.sdk.auth.linkVerify(r.challenge_id,s,{merge:!0});this.pending=null,this.afterLink(i)})}}afterLink(e){this.notice=e.merged?`Accounts combined — ${(e.credits_transferred??0).toLocaleString()} credits moved across.`:"Connected.",this.emit("openapps-identity-linked",e),w(),this.load()}async unlink(e){await this.run(async()=>{await this.sdk.auth.unlink(e),this.notice="Disconnected.",this.emit("openapps-identity-unlinked",{caip10:e}),await this.load()})}render(){if(!this.sdkOrNull)return a`<p class="muted">Loading…</p>`;if(!this.sdk.isLoggedIn)return a`<p class="muted">Sign in to manage your account.</p>`;if(!this.me)return a`<p class="muted">Loading…</p>`;if(this.pending)return this.renderMergePrompt(this.pending);const e=this.me.linked_accounts;return a`
      <div class="card">
        <div class="head">
          <div>
            <div class="muted small">Account</div>
            <code class="id">${this.me.id}</code>
          </div>
          <div class="right">
            <div class="balance">${this.me.balance.toLocaleString()}</div>
            <div class="muted small">credits</div>
          </div>
        </div>

        <h3>Sign-in methods</h3>
        <ul class="identities">
          ${e.map(t=>a`
              <li>
                <span class="tag">${le[t.namespace]??t.namespace}</span>
                <code title=${t.caip10}
                  >${zt(t.label??t.caip10)}</code
                >
                ${e.length>1?a`<button
                      class="link"
                      ?disabled=${this.busy}
                      @click=${()=>this.unlink(t.caip10)}
                    >
                      Disconnect
                    </button>`:a`<span class="muted small">only method</span>`}
              </li>
            `)}
        </ul>

        ${this.connectable.length||this.canConnectGoogle?a`
              <h3>Add another</h3>
              <div class="row">
                ${this.canConnectGoogle?a`<button ?disabled=${this.busy} @click=${()=>this.connectGoogle()}>
                      Connect Google
                    </button>`:c}
                ${this.connectable.map(t=>a`
                    <button ?disabled=${this.busy} @click=${()=>this.connect(t)}>
                      Connect ${le[t]}
                    </button>
                  `)}
              </div>
              <p class="muted small">
                Connecting a method that is already on another account will offer to
                combine them, so you keep one balance and one history.
              </p>
            `:a`<p class="muted small">Every available method is connected.</p>`}

        ${this.blocked?a`<p class="warn" role="alert">${this.blocked}</p>`:c}
        ${this.notice?a`<p class="notice">${this.notice}</p>`:c}
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      </div>
    `}renderMergePrompt(e){return a`
      <div class="card">
        <h3>Combine two accounts?</h3>
        <p>
          That ${le[e.namespace]??e.namespace} identity already
          belongs to another account holding
          <strong>${e.other.balance.toLocaleString()} credits</strong>.
        </p>
        <p class="muted small">
          Combining moves its credits, payment history and referral earnings onto
          this account, and signs it out everywhere. It cannot be undone.
        </p>
        <div class="row">
          <button class="primary" ?disabled=${this.busy} @click=${this.confirmMerge}>
            Combine them
          </button>
          <button ?disabled=${this.busy} @click=${()=>this.pending=null}>
            Cancel
          </button>
        </div>
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      </div>
    `}static{this.styles=[b.baseStyles,U`
      .card {
        border: 1px solid var(--border-hairline, var(--fb-hairline));
        border-radius: var(--radius-lg, 12px);
        padding: 1rem 1.1rem;
        background: var(--surface-card, var(--fb-card));
      }
      .head {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 1rem;
        border-bottom: 1px solid var(--border-hairline, var(--fb-hairline));
        padding-bottom: 0.75rem;
      }
      .right {
        text-align: right;
      }
      .balance {
        font-size: 1.5rem;
        font-weight: 700;
        font-variant-numeric: tabular-nums;
      }
      .id {
        font-size: 0.8rem;
        overflow-wrap: anywhere;
      }
      h3 {
        font-size: 0.9rem;
        margin: 1rem 0 0.5rem;
      }
      .identities {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: 0.4rem;
      }
      .identities li {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        font-size: 0.9rem;
      }
      .identities code {
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .tag {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        border: 1px solid var(--border-hairline, var(--fb-hairline));
        border-radius: 999px;
        padding: 0.1em 0.6em;
      }
      button.link {
        border: none;
        background: none;
        color: var(--text-muted, var(--fb-muted));
        text-decoration: underline;
        padding: 0;
        font-size: 0.85em;
      }
      .row {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
      }
      .small {
        font-size: 0.8rem;
      }
      .notice {
        font-size: 0.85rem;
        margin-top: 0.6rem;
      }
      /* Semantic tokens rather than a hardcoded pair with its own media
         query: that combination ignored the host entirely, so a page
         forcing dark kept a bright yellow warning. */
      .warn {
        font-size: 0.85rem;
        margin-top: 0.6rem;
        padding: 0.5em 0.7em;
        border-radius: var(--radius-lg, 12px);
        background: var(--warning-bg, #fef3c7);
        color: var(--warning-fg, #92400e);
      }
    `]}};B([p()],N.prototype,"me",void 0);B([p()],N.prototype,"enabled",void 0);B([p()],N.prototype,"pending",void 0);B([p()],N.prototype,"notice",void 0);B([p()],N.prototype,"blocked",void 0);N=B([D("openapps-account")],N);function zt(n,e=18,t=8){return n.length<=e+t+1?n:`${n.slice(0,e)}…${n.slice(-t)}`}var oe=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};let Y=class extends b{constructor(){super(...arguments),this.pollSeconds=0,this.label="Credits",this.balance=null}#e;connectedCallback(){super.connectedCallback(),this.refresh(),this.pollSeconds>0&&(this.#e=setInterval(()=>void this.refresh(),this.pollSeconds*1e3))}disconnectedCallback(){this.#e&&clearInterval(this.#e),super.disconnectedCallback()}onSessionChange(){this.refresh()}async refresh(){const e=this.sdkOrNull;if(!e?.isLoggedIn){this.balance=null;return}const t=await this.run(()=>e.credits.balance());t!==void 0&&(this.balance=t)}render(){return this.sdkOrNull?this.sdk.isLoggedIn?a`
      <span class="wrap">
        <span class="label muted">${this.label}</span>
        <span class="value" aria-live="polite"
          >${this.balance===null?"…":this.balance.toLocaleString()}</span
        >
      </span>
      ${this.error?a`<span class="error" role="alert">${this.error}</span>`:c}
    `:a`<span class="muted">Not signed in</span>`:a`<span class="muted">…</span>`}static{this.styles=[b.baseStyles,U`
      :host {
        display: inline-block;
      }
      .wrap {
        display: inline-flex;
        align-items: baseline;
        gap: 0.4em;
      }
      .label {
        font: var(--type-eyebrow, 500 12px/1.2 "Geist", system-ui, sans-serif);
        letter-spacing: var(--tracking-caps, 0.08em);
        text-transform: uppercase;
        color: var(--text-faint, var(--fb-faint));
      }
      /* A balance is a quantity, so it is set in mono. Tabular figures also
         stop the number jittering sideways as it ticks over on poll. */
      .value {
        font-family: var(--font-mono, "Geist Mono", ui-monospace, monospace);
        font-variant-numeric: tabular-nums;
        font-weight: var(--weight-medium, 500);
        color: var(--text-strong, var(--fb-strong));
      }
    `]}};oe([v({type:Number,attribute:"poll-seconds"})],Y.prototype,"pollSeconds",void 0);oe([v({type:String})],Y.prototype,"label",void 0);oe([p()],Y.prototype,"balance",void 0);Y=oe([D("openapps-credits")],Y);var S=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};let k=class extends b{constructor(){super(...arguments),this.pageSize=25,this.appId="",this.noSummary=!1,this.entries=[],this.cursor=null,this.complete=!1,this.loaded=!1}connectedCallback(){super.connectedCallback(),this.refresh()}onSessionChange(){this.refresh()}async refresh(){this.entries=[],this.cursor=null,this.complete=!1,this.loaded=!1,await this.loadMore()}async loadMore(){const e=this.sdkOrNull;if(!e?.isLoggedIn){this.loaded=!0;return}const t=await this.run(()=>e.credits.history({cursor:this.cursor??void 0,limit:this.pageSize}));this.loaded=!0,t&&(this.entries=[...this.entries,...t.entries],this.cursor=t.next_cursor,this.complete=t.next_cursor===null)}get visible(){return this.appId?this.entries.filter(e=>e.app_id===this.appId):this.entries}get spending(){const e=new Map;for(const t of this.visible){if(t.amount>=0)continue;const r=ge(t),s=e.get(r);s?(s.credits+=-t.amount,s.count+=1):e.set(r,{label:r,credits:-t.amount,count:1})}return[...e.values()].sort((t,r)=>r.credits-t.credits)}render(){if(!this.sdkOrNull)return a`<p class="muted">Loading…</p>`;if(!this.sdk.isLoggedIn)return a`<p class="muted">Sign in to see where your credits went.</p>`;if(!this.loaded)return a`<p class="muted">Loading…</p>`;const e=this.visible;if(e.length===0)return a`
        <p class="muted">
          Nothing yet. Credits you buy and spend both appear here, with what
          each one was for.
        </p>
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      `;const t=this.noSummary?[]:this.spending,r=t.reduce((s,i)=>s+i.credits,0);return a`
      ${t.length?a`
            <div class="summary">
              <div class="eyebrow">
                ${this.complete?"Spent, all time":"Spent, recent activity"}
              </div>
              <ul class="groups">
                ${t.map(s=>a`
                    <li>
                      <span class="what" title=${s.label}>${s.label}</span>
                      <span class="times muted"
                        >${s.count===1?"once":`${s.count}×`}</span
                      >
                      <span class="mono amount">${s.credits.toLocaleString()}</span>
                      <!-- The bar is proportional to the largest row, not to
                           the total: with one dominant item every other bar
                           would round to nothing and the comparison people
                           actually want — this against that — disappears. -->
                      <span
                        class="bar"
                        style=${`--w:${Math.round(s.credits/t[0].credits*100)}%`}
                      ></span>
                    </li>
                  `)}
              </ul>
              <p class="caption">
                ${r.toLocaleString()} credits across ${e.length}
                ${e.length===1?"entry":"entries"}${this.complete?"":" so far"}.
              </p>
            </div>
          `:c}

      <div class="eyebrow rule">Activity</div>
      <ul class="entries">
        ${e.map(s=>a`
            <li>
              <span class="when muted">${Ht(s.created_at)}</span>
              <span class="what" title=${Te(s)}
                >${Te(s)}</span
              >
              <span class="mono amount ${s.amount<0?"debit":"credit"}">
                ${s.amount>0?"+":"−"}${Math.abs(s.amount).toLocaleString()}
              </span>
              <span class="mono after muted" title="Balance after"
                >${s.balance_after.toLocaleString()}</span
              >
            </li>
          `)}
      </ul>

      ${this.cursor!==null?a`<button
            class="block"
            ?disabled=${this.busy}
            @click=${()=>void this.loadMore()}
          >
            ${this.busy?"Loading…":"Show earlier"}
          </button>`:c}
      ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
    `}static{this.styles=[b.baseStyles,U`
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
      }
      .summary {
        display: grid;
        gap: 8px;
        margin-bottom: 18px;
      }
      /* Label, count, amount — then the bar spanning the full width beneath,
         so a long feature name never squeezes the figure it belongs to. */
      .groups li {
        display: grid;
        grid-template-columns: 1fr auto auto;
        align-items: baseline;
        gap: 8px;
        padding: 5px 0;
      }
      .groups .bar {
        grid-column: 1 / -1;
        height: 3px;
        border-radius: var(--radius-full, 999px);
        background: var(--brand-soft, #e6f9f3);
        width: var(--w, 0%);
        min-width: 2px;
      }
      .times {
        font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
      }
      .rule {
        display: block;
        padding-top: 12px;
        border-top: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
      }
      .entries li {
        display: grid;
        grid-template-columns: auto 1fr auto auto;
        align-items: baseline;
        gap: 10px;
        padding: 7px 0;
        border-bottom: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
      }
      .entries li:last-child {
        border-bottom: none;
      }
      .when {
        font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
        white-space: nowrap;
      }
      /* A feature name is arbitrary text from whichever app charged; it
         truncates rather than pushing the amount off the panel. */
      .what {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: var(--text-strong, var(--fb-strong));
        font: var(--type-ui, 500 13px/1.3 "Geist", system-ui, sans-serif);
      }
      .amount {
        font-weight: var(--weight-medium, 500);
        color: var(--text-strong, var(--fb-strong));
      }
      /* Spending is the ordinary case here, so it stays in the body colour;
         only money arriving is worth a tone. Colouring every debit red would
         make a working account look like a page of errors. */
      .amount.credit {
        color: var(--success-fg, #0b8a68);
      }
      .after {
        font: var(--type-caption, 400 12px/1.35 "Geist", system-ui, sans-serif);
        min-width: 3.5em;
        text-align: right;
      }
      button.block {
        margin-top: 12px;
      }
    `]}};S([v({type:Number,attribute:"page-size"})],k.prototype,"pageSize",void 0);S([v({type:String,attribute:"app-id"})],k.prototype,"appId",void 0);S([v({type:Boolean,attribute:"no-summary"})],k.prototype,"noSummary",void 0);S([p()],k.prototype,"entries",void 0);S([p()],k.prototype,"cursor",void 0);S([p()],k.prototype,"complete",void 0);S([p()],k.prototype,"loaded",void 0);k=S([D("openapps-history")],k);function ge(n){const e=n.app_name??n.app_id??null,t=n.ref_id??null;return e&&t?`${e} · ${t}`:e||t||"Spent"}function Te(n){switch(n.kind){case"debit":return ge(n);case"topup":return"Credits purchased";case"referral_bonus":return"Referral bonus";case"adjustment":return n.ref_id?`Adjustment — ${n.ref_id}`:"Adjustment";case"refund":return n.amount<0?"Payment reversed":"Refund";default:return ge(n)}}function Ht(n){const e=new Date(n*1e3);return Number.isNaN(e.getTime())?"":e.toLocaleDateString(void 0,{month:"short",day:"numeric"})}var R=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};function Ie(n){return new Date(n*1e3).toLocaleDateString(void 0,{day:"numeric",month:"short"})}let C=class extends b{constructor(){super(...arguments),this.info=null,this.earnings=null,this.referees=null,this.tab="link",this.copied=!1}connectedCallback(){super.connectedCallback(),this.load()}onSessionChange(){this.load()}async load(){const e=this.sdkOrNull;if(!e?.isLoggedIn){this.info=null,this.earnings=null,this.referees=null;return}this.info=await this.run(()=>e.referral.code())??null,this.earnings=await this.run(()=>e.referral.earnings())??null,this.referees=await this.run(()=>e.referral.referees())??null}get link(){const e=this.inviteUrl??(typeof location>"u"?"":`${location.origin}${location.pathname}`);if(!this.info)return e;const t=e.includes("?")?"&":"?";return`${e}${t}ref=${encodeURIComponent(this.info.code)}`}async copy(){try{await navigator.clipboard.writeText(this.link),this.copied=!0,setTimeout(()=>this.copied=!1,2e3)}catch{this.error="Could not copy. Select the link and copy it manually."}}render(){if(!this.sdkOrNull)return a`<p class="muted">Loading…</p>`;if(!this.sdk.isLoggedIn)return a`<p class="muted">Sign in to get your invite link.</p>`;if(!this.info)return a`<p class="muted">${this.error??"Loading…"}</p>`;const e=this.referees?.referees??[],t=this.earnings?.entries??[],r=[["link","Your link"],["referees",`Referees${e.length?` (${e.length})`:""}`],["earnings",`Earnings${t.length?` (${t.length})`:""}`]];return a`
      <div class="stack">
        <div class="tabs" role="tablist">
          ${r.map(([s,i])=>a`
              <button
                role="tab"
                aria-selected=${this.tab===s}
                class="tab ${this.tab===s?"on":""}"
                @click=${()=>this.tab=s}
              >
                ${i}
              </button>
            `)}
        </div>
        ${this.tab==="link"?this.renderLink():this.tab==="referees"?this.renderReferees(e):this.renderEarnings(t)}
        ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
      </div>
    `}renderLink(){const e=this.earnings?.total??0,t=this.earnings?.entries.length??0;return a`
      <p class="desc">
        Share this link. When someone signs up through it and buys credits,
        you earn <strong>${this.info?.bonus_percent}%</strong> of what they
        buy, as credits.
      </p>
      <code class="payload">${this.link}</code>
      <div class="row">
        <button @click=${this.copy}>${this.copied?"Copied":"Copy link"}</button>
        <span class="muted mono">${this.info?.code}</span>
      </div>
      <div class="earned">
        <span class="eyebrow">Earned</span>
        <span class="total mono">${e.toLocaleString()}</span>
        <span class="caption">
          ${t===0?"No referred purchases yet.":`credits from ${t} purchase${t===1?"":"s"}`}
        </span>
      </div>
    `}renderReferees(e){return e.length===0?a`<p class="muted">
        Nobody has signed up through your link yet.
      </p>`:a`
      <p class="caption">
        Handles only — signing up through a link does not share someone's
        identity with you.
      </p>
      <div class="list">
        ${e.map(t=>a`
            <div class="item">
              <span class="mono handle">${t.handle}</span>
              <span class="grow caption">
                joined ${Ie(t.joined_at)} ·
                ${t.purchases===0?"no purchases yet":`${t.purchases} purchase${t.purchases===1?"":"s"}`}
              </span>
              <span class="mono amount ${t.earned>0?"good":""}">
                ${t.earned>0?`+${t.earned.toLocaleString()}`:"—"}
              </span>
            </div>
          `)}
      </div>
    `}renderEarnings(e){return e.length===0?a`<p class="muted">
        No referral earnings yet. A bonus is credited when a referee's
        purchase settles.
      </p>`:a`
      <p class="caption">
        Each row is one bonus, credited in the same transaction as the
        referee's purchase — so this list and your balance cannot disagree.
      </p>
      <div class="list">
        ${e.map(t=>a`
            <div class="item">
              <span class="mono date">${Ie(t.created_at)}</span>
              <span class="grow caption">
                ${t.referee??"unknown"}
                ${t.referee_credits?a` bought ${t.referee_credits.toLocaleString()} credits`:c}
              </span>
              <span class="mono amount good">+${t.amount.toLocaleString()}</span>
            </div>
          `)}
      </div>
    `}static{this.styles=[b.baseStyles,U`
      .stack {
        display: grid;
        gap: 12px;
      }
      .row {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .tabs {
        display: flex;
        gap: 4px;
        border-bottom: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
      }
      /* Underline tabs sitting on the hairline, with a 2px near-black
         indicator — not a filled pill, and never a coloured bar. The
         indicator is drawn on the tab itself and pulled down over the rule
         so the selected tab reads as continuous with its panel. */
      .tab {
        border: none;
        border-bottom: 2px solid transparent;
        border-radius: 0;
        background: transparent;
        color: var(--text-muted, var(--fb-muted));
        margin-bottom: -1px;
        padding: 0 10px;
      }
      .tab.on {
        border-bottom-color: var(--text-strong, var(--fb-strong));
        color: var(--text-strong, var(--fb-strong));
      }
      .tab:hover:not(.on) {
        color: var(--text-strong, var(--fb-strong));
        background: transparent;
      }
      .list {
        display: grid;
        border: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
        border-radius: var(--radius-lg, 12px);
        overflow: hidden;
      }
      .item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 14px;
      }
      .item + .item {
        border-top: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
      }
      .grow {
        flex: 1;
      }
      .date,
      .handle {
        font-size: var(--text-2xs, 11px);
        color: var(--text-faint, var(--fb-faint));
        min-width: 3.4em;
      }
      .amount {
        font-size: var(--text-sm, 13px);
        font-weight: var(--weight-medium, 500);
        color: var(--text-muted, var(--fb-muted));
      }
      .amount.good {
        color: var(--success-fg, #0b8a68);
      }
      .earned {
        display: grid;
        gap: 4px;
        padding: 14px 16px;
        border: var(--border-width, 1px) solid
          var(--border-hairline, var(--fb-hairline));
        border-radius: var(--radius-lg, 12px);
        background: var(--surface-card, var(--fb-card));
      }
      /* A balance is a quantity, so it is mono — same rule as the credit
         badge and the ledger. */
      .total {
        font-size: var(--text-3xl, 40px);
        font-weight: var(--weight-medium, 500);
        line-height: 1;
        letter-spacing: var(--tracking-display, -0.035em);
        color: var(--text-strong, var(--fb-strong));
      }
    `]}};R([v({type:String,attribute:"invite-url"})],C.prototype,"inviteUrl",void 0);R([p()],C.prototype,"info",void 0);R([p()],C.prototype,"earnings",void 0);R([p()],C.prototype,"referees",void 0);R([p()],C.prototype,"tab",void 0);R([p()],C.prototype,"copied",void 0);C=R([D("openapps-referral")],C);var E=function(n,e,t,r){var s=arguments.length,i=s<3?e:r===null?r=Object.getOwnPropertyDescriptor(e,t):r,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(n,e,t,r);else for(var l=n.length-1;l>=0;l--)(o=n[l])&&(i=(s<3?o(i):s>3?o(e,t,i):o(e,t))||i);return s>3&&i&&Object.defineProperty(e,t,i),i};let x=class extends b{constructor(){super(...arguments),this.rails="",this.returnTo="",this.packages=null,this.selected=null,this.instruction=null,this.topup=null,this.waiting=!1}#e;connectedCallback(){super.connectedCallback(),this.load()}disconnectedCallback(){this.#e?.abort(),super.disconnectedCallback()}onSessionChange(){if(!this.packages){this.load();return}this.requestUpdate()}async load(){if(!this.sdkOrNull)return;const e=await this.run(()=>this.sdk.payments.packages());e&&(this.packages=e)}get offeredRails(){if(!this.packages)return[];const e=["stripe","ethereum","lightning"].filter(r=>this.packages?.rails?.[r]),t=this.rails.split(",").map(r=>r.trim()).filter(Boolean);return t.length?e.filter(r=>t.includes(r)):e}async start(e){const t=this.selected;t&&await this.run(async()=>{let r;switch(e){case"stripe":{const s=await this.sdk.payments.stripeCheckout(t.id,{returnTo:this.returnTo==="none"?null:this.returnTo||void 0});this.instruction={kind:"redirect"},!this.dispatchEvent(new CustomEvent("openapps-checkout",{detail:{url:s.checkout_url,packageId:t.id},cancelable:!0,bubbles:!0,composed:!0}))||(window.location.href=s.checkout_url);return}case"ethereum":{const s=await this.sdk.payments.ethDepositAddress(t.id);r=s.topup_id,this.instruction={kind:"address",chain:s.chain,address:s.address,amount:s.expected_amount};break}case"lightning":{const s=await this.sdk.payments.lightningInvoice(t.id);r=s.topup_id,this.instruction={kind:"invoice",bolt11:s.bolt11,amountMsat:s.amount_msat};break}}this.watch(r,Bt[e])})}async watch(e,t){this.#e?.abort();const r=new AbortController;this.#e=r,this.waiting=!0;try{const s=await this.sdk.payments.waitFor(e,{timeoutMs:t,signal:r.signal,onPoll:i=>{this.topup=i}});this.topup=s,s.status==="confirmed"&&(this.emit("openapps-topup",s),w())}catch(s){s instanceof Error&&s.name==="AbortError"||(this.error=qt(s))}finally{this.waiting=!1}}reset(){this.#e?.abort(),this.selected=null,this.instruction=null,this.topup=null,this.error=null}render(){return this.sdkOrNull?this.sdk.isLoggedIn?this.packages?this.instruction?this.renderInstruction(this.instruction):this.selected?this.renderRails(this.selected):this.renderPackages(this.packages.packages??[]):a`<p class="muted">${this.error??"Loading packages…"}</p>`:a`<p class="muted">Sign in to buy credits.</p>`:a`<p class="muted">Loading…</p>`}renderPackages(e){return e.length===0?a`<p class="muted">No credit packages are configured.</p>`:a`
      <div class="grid">
        ${e.map(t=>a`
            <button class="package" @click=${()=>this.selected=t}>
              <span class="credits">
                ${t.credits.toLocaleString()} credits
              </span>
              <span class="perunit caption">${Wt(t)}</span>
              <span class="price">${je(t.usd_price)}</span>
            </button>
          `)}
      </div>
      ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
    `}renderRails(e){const t=this.offeredRails;return a`
      <p>
        <strong>${e.credits.toLocaleString()} credits</strong> —
        ${je(e.usd_price)}
      </p>
      <div class="stack">
        ${t.map(r=>a`
            <button class="primary" ?disabled=${this.busy} @click=${()=>this.start(r)}>
              ${Dt[r]}
            </button>
          `)}
        ${t.length===0?a`<p class="muted">No payment methods are enabled.</p>`:c}
        <button @click=${this.reset}>Back</button>
      </div>
      ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
    `}renderInstruction(e){const t=this.topup?.status??"pending";return t==="confirmed"?a`
        <span class="badge success"><span class="dot"></span>Confirmed</span>
        <p class="ok">Payment confirmed — credits added.</p>
        <button @click=${this.reset}>Buy more</button>
      `:t==="failed"||t==="expired"?a`
        <span class="badge danger"><span class="dot"></span>${t==="failed"?"Failed":"Expired"}</span>
        <p class="error" role="alert">This top-up ${t}. Nothing was charged.</p>
        <button @click=${this.reset}>Try again</button>
      `:a`
      ${e.kind==="redirect"?a`<p class="muted">Redirecting to checkout…</p>`:c}
      ${e.kind==="address"?a`
            <p>Send exactly <strong>${Ft(e.amount,6)}</strong> USDC or
            USDT on <code>${e.chain}</code> to:</p>
            <code class="payload">${e.address}</code>
          `:c}
      ${e.kind==="invoice"?a`
            <p>Pay this Lightning invoice
            (<strong>${Math.ceil(e.amountMsat/1e3).toLocaleString()} sats</strong>):</p>
            <code class="payload">${e.bolt11}</code>
          `:c}
      ${e.kind!=="redirect"?a`
            <div class="row">
              <button @click=${()=>this.copy(Gt(e))}>Copy</button>
              <button @click=${this.reset}>Cancel</button>
            </div>
            ${this.renderWaiting()}
          `:c}
      ${this.error?a`<p class="error" role="alert">${this.error}</p>`:c}
    `}renderWaiting(){if(!this.waiting)return a`<p class="muted" aria-live="polite">Not watching for payment.</p>`;const e=this.topup?.confirmations;if(e===void 0)return a`<p class="muted" aria-live="polite">Waiting for payment…</p>`;const t=this.topup?.confirmations_required;if(t==null)return a`
        <p class="muted" aria-live="polite">
          Payment received — waiting for the network to finalise it.
        </p>
      `;const r=Math.min(e,t);return a`
      <p class="muted" aria-live="polite">
        Payment received — confirming (${r} of ${t}).
      </p>
      <progress
        class="confirms"
        max=${t}
        value=${r}
        aria-label="Confirmations"
      ></progress>
    `}async copy(e){try{await navigator.clipboard.writeText(e)}catch{this.error="Could not copy — select the text and copy it manually."}}static{this.styles=[b.baseStyles,U`
      /* Packs stack as rows rather than tiles: the numbers line up down the
         right edge, which is what makes three prices comparable at a glance. */
      .grid {
        display: grid;
        gap: 8px;
      }
      .package {
        display: flex;
        align-items: center;
        gap: 14px;
        min-height: auto;
        padding: 14px 16px;
        text-align: left;
        border-radius: var(--radius-lg, 12px);
      }
      .package:hover:not([disabled]) {
        border-color: var(--border-strong, var(--fb-hairline));
      }
      .credits {
        flex: 1;
        font: var(--weight-medium, 500) var(--text-base, 15px) / 1.2
          var(--font-sans, "Geist", system-ui, sans-serif);
        color: var(--text-strong, var(--fb-strong));
      }
      /* Money is always mono — balances, prices, per-unit rates, ledger
         amounts. Tabular figures keep the column aligned across packs. */
      .price {
        font-family: var(--font-mono, "Geist Mono", ui-monospace, monospace);
        font-variant-numeric: tabular-nums;
        font-size: var(--text-md, 17px);
        color: var(--text-strong, var(--fb-strong));
      }
      .perunit {
        font-family: var(--font-mono, "Geist Mono", ui-monospace, monospace);
        font-size: var(--text-2xs, 11px);
        color: var(--text-faint, var(--fb-faint));
      }
      .stack {
        display: flex;
        flex-direction: column;
        gap: 0.5em;
      }
      .row {
        display: flex;
        gap: 0.5em;
        margin-top: 0.5em;
      }
      .ok {
        font-weight: 600;
      }
      .confirms {
        display: block;
        width: 100%;
        height: 0.4em;
        margin-top: 0.35em;
        border: none;
        border-radius: 999px;
        overflow: hidden;
        background: var(--surface-card, var(--fb-card));
        accent-color: var(--brand, var(--fb-brand));
      }
      /* WebKit ignores accent-color on <progress>, so colour it directly. */
      .confirms::-webkit-progress-bar {
        background: var(--surface-card, var(--fb-card));
      }
      .confirms::-webkit-progress-value {
        background: var(--brand, var(--fb-brand));
      }
    `]}};E([v({type:String})],x.prototype,"rails",void 0);E([v({type:String,attribute:"return-to"})],x.prototype,"returnTo",void 0);E([p()],x.prototype,"packages",void 0);E([p()],x.prototype,"selected",void 0);E([p()],x.prototype,"instruction",void 0);E([p()],x.prototype,"topup",void 0);E([p()],x.prototype,"waiting",void 0);x=E([D("openapps-buy")],x);const Dt={stripe:"Pay by card",ethereum:"Pay with USDC / USDT",lightning:"Pay with Lightning"},Bt={stripe:void 0,lightning:void 0,ethereum:1800*1e3};function Gt(n){return n.kind==="address"?n.address:n.kind==="invoice"?n.bolt11:""}function je(n){return`$${(n/100).toFixed(2)}`}function Wt(n){if(n.credits<=0)return"";const e=n.usd_price/n.credits;return`${e<1?e.toFixed(2):e.toFixed(1)}¢ each`}function Ft(n,e){const t=10**e;return(n/t).toFixed(e).replace(/\.?0+$/,"")}function qt(n){const e=n instanceof Error?n.message:String(n);return e.includes("still pending")?"Still waiting on the network. Your credits will appear once the payment settles.":e}ze({baseUrl:Xe,store:Qe});j.storage.onChanged.addListener((n,e)=>{e==="session"&&"openapps.session"in n&&location.reload()});const Vt=document.getElementById("signInCard"),Jt=document.getElementById("historyCard"),Kt=document.querySelector("openapps-buy"),X=document.getElementById("signOut");document.getElementById("signIn").addEventListener("click",()=>{j.tabs.create({url:new URL("/signin",I.baseUrl).toString()})});Kt.addEventListener("openapps-checkout",n=>{const{url:e}=n.detail;n.preventDefault(),j.tabs.create({url:e})});X.addEventListener("click",async()=>{X.disabled=!0;try{await I.auth.logout()}catch(n){console.warn("[openapps] sign-out request failed; cleared locally anyway",n)}finally{X.disabled=!1,Ye()}});const Yt=["Connect Google","Connect Wallet","Connect Nostr"];document.querySelector("openapps-account").addEventListener("click",n=>{const e=n.composedPath().find(t=>t instanceof HTMLButtonElement);!e||!Yt.includes(e.textContent?.trim()??"")||(n.stopImmediatePropagation(),n.preventDefault(),j.tabs.create({url:new URL("/link",I.baseUrl).toString()}))},!0);function Ye(){Vt.hidden=I.isLoggedIn,X.hidden=!I.isLoggedIn,Jt.hidden=!I.isLoggedIn}(async()=>(await et,Ye()))();document.getElementById("closeAccount").addEventListener("click",async()=>{const n=await j.tabs.getCurrent();n?.id!==void 0?await j.tabs.remove(n.id):window.close()});
