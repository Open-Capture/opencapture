const t=globalThis.browser??chrome;function a(){return t.tabs.MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND||2}export{a as c,t as e};
